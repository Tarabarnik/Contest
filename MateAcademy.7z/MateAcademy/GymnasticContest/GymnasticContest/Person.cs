﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymnasticContest
{
    public abstract class Person
    {
        public string Name { get; set; }
        public uint Age { get; set; }
        public Nations Nation { get; set; }
        public override string ToString()
        {
            return Name;
        }
    }
    public enum Nations
    {
        UA,
        USA,
        CHN,
        RUS,
        ENG,
        ITL
    }
}
