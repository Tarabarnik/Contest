﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymnasticContest
{
    class Contest
    {
        List<Judge> Jury;
        List<Participant> Contestants;
        public Contest()
        {
            Jury = new List<Judge>()
            {
                new Judge(){ Name = "Sergey Derkach", Age = 35, Nation = Nations.RUS},
                new Judge(){ Name = "Pavlo Zibrov", Age = 99, Nation = Nations.UA},
                new Judge(){ Name = "Lee Xang", Age = 42, Nation = Nations.CHN},
                new Judge(){ Name = "Antonio Giovanni", Age = 28, Nation = Nations.ITL},
                new Judge(){ Name = "Sir Markus Edwards", Age = 60, Nation = Nations.ENG}
            };
            Contestants = new List<Participant>();
        }
        public void AddParticipant(Participant p)
        {
            Contestants.Add(p);
        }
        public void StartContest()
        {
            foreach(var p in Contestants)
            {
                Console.Write("Participant's second name => ");
                p.Name = Console.ReadLine();
                foreach (var j in Jury)
                {
                    j.Evaluate(p);
                }
                Console.Write(p + " ");
                foreach(double d in p)
                {
                    Console.Write(d + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine("Contest is over and it's time to show results!");
            PrintRes();
        }
        public void PrintRes()
        {
            Console.Write("Options of output:\n1.By rating\n2.By name\n3.By participating order\nEnter number of chosen option =>");
            int num;
            if (Int32.TryParse(Console.ReadLine(), out num))
            {
                if(num < 1 || num > 3)
                {
                    Console.WriteLine("Wrong number. Please, try again");
                    PrintRes();
                }
                IEnumerable<Participant> list = new List<Participant>();
                switch(num)
                {
                    case 1:
                        {
                            list = from p in Contestants
                                   orderby p.Avg
                                   select p;
                        }
                            break;
                    case 2:
                        {
                            list = from p in Contestants
                                   orderby p.Name
                                   select p;
                        }
                            break;
                    case 3:
                        {
                            list = Contestants;
                        }
                            break;
                }
                foreach(var p in list)
                {
                    Console.WriteLine($"{p} {p.Avg}");
                }
                Console.WriteLine("The End :)");
            }
            else
            {
                Console.WriteLine("Wrong input. Please, try again");
                PrintRes();
            }
        }
    }
}
