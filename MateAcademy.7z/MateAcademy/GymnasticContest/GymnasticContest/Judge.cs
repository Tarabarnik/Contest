﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymnasticContest
{
    public class Judge : Person
    {
        Random rnd = new Random();

        public void Evaluate(Participant participant)
        {
            if(this.Nation != participant.Nation)
            {
                double pts = rnd.NextDouble() * 6;
                participant.AddPoints(pts);
            }
        }
    }
}
