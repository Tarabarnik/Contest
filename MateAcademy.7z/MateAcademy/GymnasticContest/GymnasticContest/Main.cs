﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymnasticContest
{
    class main
    {
        public static void AddContestants(Contest contest)
        {
            Random rnd = new Random();
            Console.Write("Enter the number of participants =>");
            int num;
            if(Int32.TryParse(Console.ReadLine(),out num))
            {
                if(num < 2 || num > 10)
                {
                    Console.WriteLine("Number of participants from 2 to 10, please");
                    AddContestants(contest);
                }
                for(int i = 0; i < num; i++)
                {
                    contest.AddParticipant(new Participant() { Age = (uint)rnd.Next(16, 25), Nation = (Nations)rnd.Next(0, 7) });
                }
                Console.WriteLine("Contestants are ready!");
            }
            else
            {
                Console.WriteLine("Incorrect input. Please, try again");
                AddContestants(contest);
            }
        }
        static void Main(string[] args)
        {
            try
            {
                Contest contest = new Contest();
                Console.WriteLine("Welcome to \"The International Gymnastics Contest\"");
                AddContestants(contest);
                contest.StartContest();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
