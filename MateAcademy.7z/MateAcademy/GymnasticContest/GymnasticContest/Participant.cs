﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymnasticContest
{
    public class Participant : Person, IEnumerable
    {
        List<double> Points;
        public double Avg
        {
            get
            {
                List<double> list = Points;
                list.Sort();
                double sum = 0;
                for(int i = 1; i < list.Count - 1; i++)
                {
                    sum += Points[i];
                }
                return sum / (list.Count - 2);
            }
        }
        public Participant()
        {
            Points = new List<double>();
        }
        public double this[int pos]
        {
            get => Points[pos];
        }
        public void AddPoints(double p)
        {
            Points.Add(p);
        }
        public IEnumerator GetEnumerator()
        {
            return Points.GetEnumerator();
        }
    }
}
